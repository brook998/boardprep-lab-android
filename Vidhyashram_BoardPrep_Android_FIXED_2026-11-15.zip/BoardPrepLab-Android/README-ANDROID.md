# Vidhyashram BoardPrep Lab Android app

This project wraps the live BoardPrep Lab website:
https://brook998.github.io/boardprep-lab/

The app requires an internet connection. Website updates appear when students reopen or refresh the app. Progress remains saved locally on each device; it is not cloud-synced.

Build from this folder with `gradle assembleDebug`. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.
