# Vidhyashram BoardPrep Lab Android wrapper

This Android app opens the live BoardPrep Lab website:
https://brook998.github.io/boardprep-lab/

It requires an internet connection. Website updates appear automatically when students reopen or refresh the app. Student progress remains local to each device; it is not cloud-synced.

## Build
Run `gradle assembleDebug` from this project directory. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.
